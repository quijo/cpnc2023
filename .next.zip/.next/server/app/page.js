(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 7999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 7244:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 8825:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRouter: () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   LayoutRouter: () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   RenderFromTemplateContext: () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   StaticGenerationSearchParamsBailoutProvider: () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   __next_app_webpack_require__: () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   actionAsyncStorage: () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   createSearchParamsBailoutProxy: () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   decodeAction: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   decodeReply: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   preconnect: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   preloadFont: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   preloadStyle: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   renderToReadableStream: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   requestAsyncStorage: () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   serverHooks: () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   staticGenerationAsyncStorage: () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   staticGenerationBailout: () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2527);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2387)), "F:\\cpnc\\src\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2819))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8447))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9450)), "F:\\cpnc\\src\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2819))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8447))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["F:\\cpnc\\src\\app\\page.js"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 1838:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7977, 23))

/***/ }),

/***/ 7518:
/***/ ((module) => {

// Exports
module.exports = {
	"mainContainer": "page_mainContainer__bdewU",
	"container": "page_container__HHToX",
	"textContainer": "page_textContainer__M_DR1",
	"imageContainer": "page_imageContainer__vC_Da",
	"img": "page_img__p8RFt",
	"move": "page_move__B8BMe",
	"btnNew": "page_btnNew__xX4_Q",
	"btnOld": "page_btnOld__mgZ3Q",
	"btnCollege": "page_btnCollege__44NfA",
	"details": "page_details__W_hF3",
	"enrollBtn": "page_enrollBtn__S3ywq",
	"title": "page_title__yhPp_",
	"desc": "page_desc__5fHBq"
};


/***/ }),

/***/ 1356:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "card_container__FFUzM",
	"imgContainer": "card_imgContainer__zHorQ",
	"cardDesc": "card_cardDesc__0cdxJ",
	"cardTitle": "card_cardTitle__XDGTb",
	"btnContainer": "card_btnContainer__0BaGL",
	"btnNew": "card_btnNew__jNQPR",
	"btnOld": "card_btnOld__BSDT6"
};


/***/ }),

/***/ 8783:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "college_container__8uVXj",
	"content": "college_content__rZZvb",
	"text": "college_text__it_KY",
	"textTitle": "college_textTitle__eOwG2",
	"contact": "college_contact__x7mQi",
	"mode": "college_mode__aEe6N",
	"img": "college_img__pGXTY",
	"move": "college_move__lH_2C",
	"status": "college_status__32GOh",
	"courseList": "college_courseList__xZcsZ",
	"start": "college_start__2bIOk",
	"end": "college_end__oZQ_W",
	"enroll": "college_enroll__Z4hPf",
	"desc": "college_desc__2QUk7",
	"pic": "college_pic__QjFk0"
};


/***/ }),

/***/ 462:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "courses_container__pH9AR",
	"cardContainer": "courses_cardContainer__F6dI0"
};


/***/ }),

/***/ 246:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "mission_container__MDWI6",
	"textContainer": "mission_textContainer__Ih9K6",
	"title": "mission_title__YspqY",
	"desc": "mission_desc__ABMbO",
	"imgContainer": "mission_imgContainer__j_2af",
	"img": "mission_img__fPvJT"
};


/***/ }),

/***/ 2387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./src/app/page.module.css
var page_module = __webpack_require__(7518);
var page_module_default = /*#__PURE__*/__webpack_require__.n(page_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(7887);
// EXTERNAL MODULE: ./src/components/mission/mission.module.css
var mission_module = __webpack_require__(246);
var mission_module_default = /*#__PURE__*/__webpack_require__.n(mission_module);
;// CONCATENATED MODULE: ./src/components/mission/Mission.jsx




const Mission = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        className: (mission_module_default()).container,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (mission_module_default()).textContainer,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: (mission_module_default()).title,
                    children: "OUR MISSION"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (mission_module_default()).imgContainer,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/mission.svg",
                            width: 50,
                            height: 50,
                            alt: "cpnc qoute",
                            className: (mission_module_default()).img
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (mission_module_default()).desc,
                            children: "Mentoring every generation of transformational leaders through quality holistic education and exemplary Christ-centered life that influence the church and the global community."
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const mission_Mission = (Mission);

// EXTERNAL MODULE: ./src/components/courses/courses.module.css
var courses_module = __webpack_require__(462);
var courses_module_default = /*#__PURE__*/__webpack_require__.n(courses_module);
// EXTERNAL MODULE: ./src/components/card/card.module.css
var card_module = __webpack_require__(1356);
var card_module_default = /*#__PURE__*/__webpack_require__.n(card_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(4834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/card/Card.jsx





const Card = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (card_module_default()).container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (card_module_default()).imgContainer,
                style: {
                    backgroundColor: props.bg
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: props.src,
                    width: 150,
                    height: 150,
                    alt: props.alt
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: (card_module_default()).cardTitle,
                children: props.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: (card_module_default()).cardDesc,
                children: props.desc
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (card_module_default()).btnContainer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "https://vnbc-essentiel.ckgroup.ph/preregv2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (card_module_default()).btnNew,
                            children: "New Student"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "https://vnbc-essentiel.ckgroup.ph/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (card_module_default()).btnOld,
                            children: "Old Student"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const card_Card = (Card);

;// CONCATENATED MODULE: ./src/components/courses/Courses.jsx




const Courses = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: (courses_module_default()).container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                children: "Courses"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (courses_module_default()).cardContainer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(card_Card, {
                        title: "Preschool",
                        desc: "Prechool has a dual commitment to provide basic and Christian Education for Pre –Schoolers in the nearby community. It adopts the philosophy of making Christian Education as center of its curriculum. It is committed to provide a wholesome learning for the development of children recognizing them as whole persons with physical, mental, social, emotional, and spiritual needs.",
                        bg: "#0e3854",
                        src: "/preschool.svg",
                        alt: "cpnc preschool"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(card_Card, {
                        title: "Elementary",
                        desc: "Elementary Department exists to provide the best possible learning for pupils in knowledge, in character and skills development.",
                        bg: "#067eed",
                        src: "/elementary.svg",
                        alt: "cpnc elementary"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(card_Card, {
                        title: "Junior High School",
                        desc: "High School Department exists to provide the best possible venue for secondary students where they can best prepare for their college education. A place where students are at par with the world’s best in knowledge, music, IT, and fluency in communication.",
                        bg: "#ff7c1f",
                        src: "/highschool.svg",
                        alt: "cpnc junior high school"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(card_Card, {
                        title: "Senior High School",
                        desc: "DepEd has developed a curriculum specifically for Senior High. It is composed of two basic components: a Core Curriculum composed of eight Learning Areas and four different career tracks that student can Choose from based on their interest and aptitude . The choice of career track will define the contents of the other subject a student will be taken in Grade 11 and 12.",
                        bg: "#c1e6ff",
                        src: "/senior.svg",
                        alt: "cpnc senior high school"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const courses_Courses = (Courses);

// EXTERNAL MODULE: ./src/components/college/college.module.css
var college_module = __webpack_require__(8783);
var college_module_default = /*#__PURE__*/__webpack_require__.n(college_module);
;// CONCATENATED MODULE: ./src/components/college/College.jsx




const College = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        id: "college",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (college_module_default()).container,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: (college_module_default()).status,
                    children: "College Department"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (college_module_default()).content,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (college_module_default()).img,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/college.svg",
                                width: 300,
                                height: 300,
                                alt: "cpnt college",
                                className: (college_module_default()).pic
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (college_module_default()).text,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: (college_module_default()).textTitle,
                                    children: "Enrollment is Now Going On"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: (college_module_default()).courseList,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Bachelor of arts in theology"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: "Bachelor of arts in religious education"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: (college_module_default()).start,
                                    children: "classes start - aug. 7, 2023"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: (college_module_default()).end,
                                    children: "enrollment ends - aug 4, 2023"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: (college_module_default()).desc,
                                    children: [
                                        "Isaiah 6:8  ”Then I heard the voice of the Lord saying, 'Whom shall I send, and who will go for us? 'And I said, 'Here am I; send me!”",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "This is your time to answer God's call for you!  Say YES and ENROLL at Central Philippine Nazarene College "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (college_module_default()).contact,
                                    children: "Please contact: (032) 505-5131 / registrar@vnbc.edu.ph"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const college_College = (College);

;// CONCATENATED MODULE: ./src/app/page.js







function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: (page_module_default()).mainContainer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (page_module_default()).container,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (page_module_default()).textContainer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: (page_module_default()).title,
                                children: "Mentoring Transformational Leaders"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (page_module_default()).desc,
                                children: "Central Philippine Nazarene College is committed to mentor transformational leaders of the next generation. We exist to provide quality Christian education, to recognize God's call and to serve the community with excellence. Partner with us in shaping the lives of our learners and equip them for their future."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (page_module_default()).enrollmentBtn,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Enroll Now!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "https://vnbc-essentiel.ckgroup.ph/preregv2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (page_module_default()).btnNew,
                                            children: "New Student"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "https://vnbc-essentiel.ckgroup.ph/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (page_module_default()).btnOld,
                                            children: "Old Student"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#college",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (page_module_default()).btnCollege,
                                            children: "College"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (page_module_default()).details,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (page_module_default()).start,
                                        children: "classes start - aug. 7, 2023"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (page_module_default()).end,
                                        children: "enrollment ends - aug 4, 2023"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (page_module_default()).imageContainer,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/hero4.svg",
                            width: 600,
                            height: 400,
                            alt: "cpnc",
                            className: (page_module_default()).img
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(mission_Mission, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(courses_Courses, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(college_College, {})
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [381,912,412], () => (__webpack_exec__(8825)));
module.exports = __webpack_exports__;

})();