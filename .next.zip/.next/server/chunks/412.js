exports.id = 412;
exports.ids = [412];
exports.modules = {

/***/ 6538:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3100, 23))

/***/ }),

/***/ 2932:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7977, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2655))

/***/ }),

/***/ 2655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ navbar_Navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./src/components/navbar/navbar.module.css
var navbar_module = __webpack_require__(3980);
var navbar_module_default = /*#__PURE__*/__webpack_require__.n(navbar_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9483);
;// CONCATENATED MODULE: ./src/app/icon.png
/* harmony default export */ const icon = ({"src":"/_next/static/media/icon.5b82962a.png","height":342,"width":340,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABCklEQVR42mMAgeaWxQLV1XOnlVXNv5YQ132+IHdSBQMMLFu2W6S5edHVlav2/j+67+j/G7ef/J81f/v/6qrZKxlAIC1twtJdu07837HtyM9j3eH//l7b9PfX60e/+6ds+J+W2J3CUF0958W9e0/+d05Y+29zQ+n/Zw2u//+dOfnn8Onr/6ND2jYwVNQsePrg+rX/hzeu+lfl3fr/SVre/78ntvw5euLi/6SEvjUMmTlTZ2xYt+f/n/uHfz5fkPL3/6aaP1/vn/szYep6kBWRDAwMwlz7Dh0/fP3+o/9vHl77/+TJ/f/nrt/6v2Ll1hkMMPD//3+WNRvWVx06fWHfrgOHt69bvzkeJgcA5Pmbx4vxYpQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/navbar/Navbar.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const Navbar_open = /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
    src: "/menu.png",
    width: 20,
    height: 20,
    alt: "cpnc"
});
const Navbar_close = /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
    src: "/close.png",
    width: 20,
    height: 20,
    alt: "cpnc"
});
const links = (/* unused pure expression or super */ null && ([]));
const Navbar = ()=>{
    const pathname = (0,navigation.usePathname)();
    const [menu, setMenu] = (0,react_.useState)(true);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (navbar_module_default()).container,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (navbar_module_default()).logo,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: icon,
                            width: 80,
                            height: 80,
                            alt: "cpnc"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                        href: "/",
                        children: [
                            " CENTRAL PHILIPPINE ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            " NAZARENE COLLEGE"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (navbar_module_default()).navbarMenu,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "https://vnbc-essentiel.ckgroup.ph/",
                    target: "blank",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: (navbar_module_default()).loginBtn,
                        children: "Login"
                    })
                })
            })
        ]
    });
};
/*
 <button className={styles.menuBtn}  onClick={()=>{setMenu(!menu)}}>{!menu ? open: close}</button>
!menu===true ? styles.activeLinks : 


 //   <Link
              //     className={`${isActive ? 'active' :null} `} 
              //     href={link.url}
              //     key={link.id}
              //  >
               
              //     {link.title}
              //   </Link>


                {links.map((link) => {
              const isActive = pathname.startsWith(link.url)
              return (
    )
            })}
 */ /* harmony default export */ const navbar_Navbar = (Navbar);


/***/ }),

/***/ 3264:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "footer_container__3MeST",
	"social": "footer_social__wfezv",
	"contact": "footer_contact__uqFd_",
	"location": "footer_location__f7EOs",
	"copyright": "footer_copyright__rOQZP",
	"email": "footer_email__23Jm6"
};


/***/ }),

/***/ 3980:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "navbar_container__iE2vU",
	"logo": "navbar_logo__M4SlJ",
	"navbarMenu": "navbar_navbarMenu__T90_Y",
	"loginBtn": "navbar_loginBtn__fg7mV",
	"enrollBtn": "navbar_enrollBtn__SfWqo"
};


/***/ }),

/***/ 9450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\app\\layout.js","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(2220);
var target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./src/app/globals.css
var globals = __webpack_require__(5553);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1313);
;// CONCATENATED MODULE: ./src/components/navbar/Navbar.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`F:\cpnc\src\components\navbar\Navbar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Navbar = (__default__);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(7887);
// EXTERNAL MODULE: ./src/components/footer/footer.module.css
var footer_module = __webpack_require__(3264);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(4834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/footer/Footer.jsx





const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (footer_module_default()).container,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default()).location,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/loc.png",
                                width: 30,
                                height: 30
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Saint Mary's Drive Apas, Cebu City"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default()).contact,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/call.png",
                                width: 30,
                                height: 30,
                                alt: "cpnc contact"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "+63 032 505-5131"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default()).social,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://www.facebook.com/cpncMain",
                                target: "blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/facebook.png",
                                    width: 30,
                                    height: 30,
                                    alt: "cpnc social"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://www.facebook.com/cpncMain",
                                target: "blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "CPNC/facebook"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default()).email,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/mail.png",
                                width: 30,
                                height: 30,
                                alt: "cpnc email"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "registrar@vnbc.edu.ph"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (footer_module_default()).copyright,
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "Central Philippine Nazarene College Inc. \xa92023  | All Rights Reserved"
                })
            })
        ]
    });
};
/* harmony default export */ const footer_Footer = (Footer);

;// CONCATENATED MODULE: ./src/app/layout.js





const metadata = {
    title: "CPNC",
    description: "Central Philippi"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            className: (target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default()).className,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
                        children
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(footer_Footer, {})
            ]
        })
    });
}


/***/ }),

/***/ 2819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 8447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/png","sizes":"340x342"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "icon.png")

    return [{
      ...imageData,
      url: imageUrl + "?5b82962a406294d0",
    }]
  });

/***/ }),

/***/ 5553:
/***/ (() => {



/***/ })

};
;